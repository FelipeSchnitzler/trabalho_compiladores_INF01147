#include "generateASM.h"

/*
===========================================================================================
 Facilitadores
==============================================================================================
*/
RegisterMap registerMapping[NUM_REGISTERS]; 
int nextFreeRegister = 0; 

/*
============================================================================================
 ASSEMBLY GENERATION
===============================================================================================
*/

/* Função auxiliar para traduzir ILOC para Assembly */
void translateIlocToAsm(IlocInstruction_t* instr, int isEnd) {
        
    if (instr->op[0] == 'L') {
        printf("\n%s:\n", instr->op);
    }
    else if (strcmp(instr->op, "loadI") == 0) {
        char* dest = allocateRegister(instr->arg3);
        printf("\tmovl\t$%s, %s", instr->arg1, dest);
        imprimeIlocInstruction(instr);

    } else if (strcmp(instr->op, "storeAI") == 0) {
        char* src;
        if(instr->arg1[0] != 'r'){
            src = calloc(strlen(instr->arg1) + 2, sizeof(char));
            sprintf(src, "$%s", instr->arg1);
        } else { 
            src = allocateRegister(instr->arg1);
        }

        //----------------------------------------------------------------------------

        printf("\tmovl\t%s, -%s(%%rbp)", src, instr->arg3);
        imprimeIlocInstruction(instr);
    } else if (strcmp(instr->op, "loadAI") == 0) {    
        char* dest = isEnd == 0 ? allocateRegister(instr->arg3) : "%eax";
        printf("\tmovl\t-%s(%%rbp), %s", instr->arg2, dest);
        imprimeIlocInstruction(instr);

    } else if (strcmp(instr->op, "RETURN") == 0){ 
        printf("\tret\n");
    } else if (strcmp(instr->op, "jumpI") == 0) {
        printf("\tjmp\t%s", instr->arg1);
        imprimeIlocInstruction(instr);
    } else if (strcmp(instr->op, "cbr") == 0) {
        char* src = allocateRegister(instr->arg1);
        printf("\tcmpl\t$0, %s\n", src);
        printf("\tje\t%s\n", instr->arg3);
        printf("\tjmp\t%s", instr->arg2);
        imprimeIlocInstruction(instr);
    } else {
        ComparisonType cmp = string_to_comparison_type(instr->op);
        BinaryOperationType binOp = string_to_binary_operation_type(instr->op);

        if (cmp != cmp_UNKNOWN) {
            handleComparison(cmp, instr);
        } 
        else if (binOp != bin_UNKNOWN) {
            handleBinaryOperation(binOp, instr);
        } 
        else if (strcmp(instr->op, "and") == 0 || strcmp(instr->op, "or") == 0 || strcmp(instr->op, "not") == 0) {
            handleLogicalOperation(instr);
        } 
        else { 
            fprintf(stderr, "Operacao Invalida : %s\n", instr->op);
        }
    }
}

/* ==========================================================================
 * Função principal para gerar e imprimir o código Assembly 
 * ==========================================================================*/
void generateASM(IlocList_t* ilocList) {
    // Cabeçalho do Assembly
    printf("\t.file\t\"program.c\"\n");
    printf("\t.text\n");
    printf("\t.globl\tmain\n");
    printf("\t.type\tmain, @function\n");
    printf("main:\n");
    printf("\t# Prologo\n");
    printf("\tpushq\t%%rbp\n");
    printf("\tmovq\t%%rsp, %%rbp\n");

    // ================================================
    printf("\n\t;#Main \n");
    // ================================================

    // Traduzir cada instrução ILOC para Assembly
    IlocList_t* current = ilocList;
    while (current != NULL) {
        /* if operation === RETURN:  */
        if(strcmp(current->instruction->op, "RETURN") == 0){
            // nextFreeRegister = 8 ;
            int isEnd = 1;
            translateIlocToAsm(current->next->instruction, isEnd);    
            current = current->next->next;
            continue;
        }else if ((strcmp(current->instruction->op, "loadI") == 0) && (strcmp(current->next->instruction->op, "storeAI") == 0)) {
            char *temp = calloc(strlen(current->instruction->arg1) + 1, sizeof(char));
            strcpy(temp, current->instruction->arg1);
            current = current->next;
            current->instruction->arg1 = temp;
            translateIlocToAsm(current->instruction, 0);
            current = current->next;
            free(temp);
            continue;
        } else if (
            (strcmp(current->instruction->op, "loadAI") == 0) &&
            (strcmp(current->next->instruction->op, "loadAI") == 0) &&
            (
                (strcmp(current->next->next->instruction->op, "mult") == 0)
                ||
                (strcmp(current->next->next->instruction->op, "div") == 0))
        ){
            char *desloc_1 = calloc(strlen(current->instruction->arg1) + 1, sizeof(char));
            char *desloc_2 = calloc(strlen(current->next->instruction->arg1) + 1, sizeof(char));

            strcpy(desloc_1, current->instruction->arg2);
            strcpy(desloc_2, current->next->instruction->arg2);
           
            current = current->next->next;

        
            printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
            imprimeIlocInstruction(current->instruction);
            imprimeIlocInstruction(current->next->instruction);
            printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

            current->instruction->arg1 = desloc_1;
            current->instruction->arg2 = desloc_2;
            
            // translateIlocToAsm(current->instruction, 0);
            optimizeASMDivMultiplication(desloc_1, desloc_2, current->instruction, current->next->instruction);


            current = (strcmp(current->next->instruction->op, "storeAI") == 0) ?  current->next->next : current->next;
            

            
            free(desloc_1);
            free(desloc_2);
            continue;
        } else if (
            (strcmp(current->instruction->op, "loadAI") == 0) &&
            (strcmp(current->next->instruction->op, "loadI") == 0) &&
            (
                (strcmp(current->next->next->instruction->op, "sub") == 0) ||
                (strcmp(current->next->next->instruction->op, "add") == 0)
            ) && 
            (strcmp(current->next->next->next->instruction->op, "storeAI") == 0) && 
            (strcmp(current->instruction->arg1, current->next->next->next->instruction->arg2) == 0) &&  // rfp == rfp ?
            (strcmp(current->instruction->arg2, current->next->next->next->instruction->arg3) == 0) // desloc == desloc ?
        ) {
            /*
                Simplificar: 
            	    movl	-4(%rbp), %r15d	; # loadAI rfp, 4 => r11
	                movl	$1, %r8d	; # loadI 1 => r12
	                subl	%r8d, %r9d
	                movl	%r9d, %r10d
	                movl	%r10d, -4(%rbp)	; # storeAI r13 => rfp, 4
                Para: 
                    subl	$1, -4(%rbp) 
            */
            char *desloc = calloc(strlen(current->instruction->arg1) + 1, sizeof(char));
            // printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
            // printf("##########################");
            imprimeIlocInstruction(current->instruction);
            
            // printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
            sprintf(desloc, "%s", current->instruction->arg2);
            char *incremento = calloc(strlen(current->next->instruction->arg1) + 1, sizeof(char));
            sprintf(incremento, "$%s", current->next->instruction->arg1);

            current = current->next->next;
            printf("\n\t %sl\t%s, -%s(%%rbp)\n", current->instruction->op, incremento, desloc);
            current = current->next->next;
            free(desloc);
            free(incremento);
            continue;

        }

        translateIlocToAsm(current->instruction, 0);
        current = current->next;
    }
    

    printf("\tpopq\t%%rbp\n");
    printf("\tret\n");
}

/* ======================================================= 
 *  Alocacao de Registradores
 * ======================================================= */

char* allocateRegister(char* virtualReg) {
    // Verifica se já existe mapeamento
    for (int i = 0; i < nextFreeRegister; i++) {
        // printf("\n=============== virtualReg: %s\n", virtualReg);
        if (strcmp(registerMapping[i].virtualReg, virtualReg) == 0) {
            return registerMapping[i].physicalReg;
        }
    }

    // Se todos os registradores físicos estão ocupados, reutiliza o primeiro
    nextFreeRegister = nextFreeRegister >= NUM_TEMP_REGISTERS ? 0 : nextFreeRegister;

    char* physicalReg;
    switch (nextFreeRegister) {
        case 0: physicalReg = "%r8d"; break;
        case 1: physicalReg = "%r9d"; break;
        case 2: physicalReg = "%r10d"; break;
        case 3: physicalReg = "%r11d"; break;
        case 4: physicalReg = "%r12d"; break;
        case 5: physicalReg = "%r13d"; break;
        case 6: physicalReg = "%r14d"; break;
        case 7: physicalReg = "%r15d"; break;
        case 8: physicalReg = "%eax"; break;
        case 9: physicalReg = "%ebx"; break;
        case 10: physicalReg = "%ecx"; break;
        case 11: physicalReg = "%edx"; break;
        case 12: physicalReg = "%esi"; break;
        case 13: physicalReg = "%edi"; break;
        case 16: physicalReg = "%eax"; break;
        default:
            physicalReg = "UNKNOWN";
            break;
    }


    
    registerMapping[nextFreeRegister].virtualReg = strdup(virtualReg);
    registerMapping[nextFreeRegister].physicalReg = strdup(physicalReg);
    nextFreeRegister++;

    return physicalReg;
}
/* ======================================================= 
 *  Comparacao
 * ======================================================= */

void handleComparison(ComparisonType cmp, IlocInstruction_t* instrucao) {
    /* ref: https://cs.wellesley.edu/~cs240/s16/slides/x86-control.pdf ;
     * slide 5;
     */
    char* s1 = allocateRegister(instrucao->arg2);
    char* s2 = allocateRegister(instrucao->arg1);
    char *dest = allocateRegister(instrucao->arg3);
    
    printf("\n");
    imprimeIlocInstruction(instrucao);
    printf("\tcmpl\t%s, %s\n", s1, s2);
    
    switch (cmp) {
        case cmp_LT:
            printf("\tsetl\t%%al\n");
            break;
        case cmp_GT:
            printf("\tsetg\t%%al\n");
            break;
        case cmp_LE:
            printf("\tsetle\t%%al\n");
            break;
        case cmp_GE:
            printf("\tsetge\t%%al\n");
            break;
        case cmp_EQ:
            printf("\tsete\t%%al\n");
            break;
        case cmp_NE:
            printf("\tsetne\t%%al\n");
            break;
        default:
            break;
    }

    printf("\tmovzbl\t%%al, %s \n\n", dest);  
}

ComparisonType string_to_comparison_type(const char* str) {
    if (strcmp(str, "cmp_LT") == 0) return cmp_LT;
    if (strcmp(str, "cmp_GT") == 0) return cmp_GT;
    if (strcmp(str, "cmp_LE") == 0) return cmp_LE;
    if (strcmp(str, "cmp_GE") == 0) return cmp_GE;
    if (strcmp(str, "cmp_EQ") == 0) return cmp_EQ;
    if (strcmp(str, "cmp_NE") == 0) return cmp_NE;

    return cmp_UNKNOWN;  // Retorna cmp_UNKNOWN se não for encontrado
}
/* ======================================================= 
 *  Operacoes Binarias (Aritmeticas) 
 * ======================================================= */
 
BinaryOperationType string_to_binary_operation_type(const char* op) {
    if (strcmp(op, "add") == 0) {
        return bin_ADD;
    } else if (strcmp(op, "sub") == 0) {
        return bin_SUB;
    } else if (strcmp(op, "mult") == 0) {
        return bin_MUL;
    } else if (strcmp(op, "div") == 0) {
        return bin_DIV;
    } else if (strcmp(op, "mod") == 0) {
        return bin_MOD;
    } else if (strcmp(op, "rsubI") == 0) {
        return bin_RSUBI;
    }
    else {
        return bin_UNKNOWN;
    }
}

void handleBinaryOperation(BinaryOperationType binOp, IlocInstruction_t* instr) {
    /* Lógica para operações binárias
     * O código assembly gerado depende do tipo da operação binária.
     */
    char* s1 = instr->arg2[0] == 'r' ? allocateRegister(instr->arg2) : instr->arg2;
    char* s2 = instr->arg1[0] == 'r' ? allocateRegister(instr->arg1) : instr->arg1;
    char* dest = allocateRegister(instr->arg3);

    printf("\n");
    imprimeIlocInstruction(instr);
    
    switch (binOp) {
        case bin_ADD:
            printf("\taddl\t%s, %s\n", s1, s2);
            printf("\tmovl\t%s, %s\n", s2, dest);
            break;
        case bin_SUB:
            printf("\tsubl\t%s, %s\n", s1, s2);
            printf("\tmovl\t%s, %s\n", s2, dest);
            break;
        case bin_MUL:
            printf("\tmovl\t%s, %%eax\n", s1);
            printf("\timull\t%s, %%eax\n", s2);
            printf("\tmovl\t%%eax, %s\n", dest);
            break;
        case bin_DIV:
            printf("\tmovl\t%s, %%eax\n", s2);
            printf("\tcltd\n");
            printf("\tidivl\t%s\n", s1);
            printf("\tmovl\t%%eax, %s\n", dest);
            break;
        case bin_MOD:
            printf("\tmovl\t%s, %%eax\n", s2);
            printf("\tcltd\n");
            printf("\tidivl\t%s\n", s1);
            printf("\tmovl\t%%edx, %s\n", dest);
            break;
        case bin_RSUBI:
            printf("\tmovl\t%s, %%eax\n", s2);  // Carrega s2 em EAX
            printf("\tnegl\t%%eax\n");          // Negação: 0 - EAX
            printf("\tmovl\t%%eax, %s\n", dest); // Move para destino
            break;
        default:
            printf("Unknown binary operation\n");
            break;
    }
    
    printf("\n");
}

/* ======================================================= 
 * Operacoes Logicas: AND,OR y NOT 
 * ======================================================= */
void handleLogicalOperation(IlocInstruction_t* instr) {
    char* s1 = allocateRegister(instr->arg1);
    char* s2 = instr->arg2 != NULL ? allocateRegister(instr->arg2) : NULL;
    char* dest = allocateRegister(instr->arg3);

    printf("\n");
    imprimeIlocInstruction(instr);

    if (strcmp(instr->op, "and") == 0) {
        printf("\tandl\t%s, %s\n", s1, s2);
        printf("\tmovl\t%s, %s\n", s2, dest);
    } 
    else if (strcmp(instr->op, "or") == 0) {
        printf("\torl\t%s, %s\n", s1, s2);
        printf("\tmovl\t%s, %s\n", s2, dest);
    } else if (strcmp(instr->op, "not") == 0) {
        printf("\tnotl\t%s\n", s1);
        printf("\tmovl\t%s, %s\n", s1, dest);
    } else {
        fprintf(stderr, "Operacao logica desconhecida: %s\n", instr->op);
    }
}

void optimizeASMDivMultiplication(char *temp1, char *temp2, IlocInstruction_t* instr, IlocInstruction_t* next) {
// void optimizeASMDivMultiplication(char *temp1, char *temp2, IlocInstruction_t* instr) {


    int bin_op = string_to_binary_operation_type(instr->op);

    char* op = instr->op;
    char* dest = allocateRegister(instr->arg3);
    
    if(bin_op == bin_MUL)
    {
        printf("\n\t ; # ++++++++++ [ MUL ] ++++++++++++++++++++++++++++++++++++++++++++++++\n");
        printf("\n\t ; #  %s\n", instr->op);
        printf("\n\t ; # temp1: %s :: temp2: %s\n", temp1, temp2);
        
        printf("\tmovl\t-%s(%%rbp), %%eax\n", temp1);
        printf("\timull\t-%s(%%rbp), %%eax\n", temp2);

         if((strcmp(next->op, "storeAI") == 0)){
            printf("\tmovl\t%%eax, -%s(%%rbp)\n", next->arg3);
         } else { 
            printf("\tmovl\t%%eax, %s\n", dest);
         }
        printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    }else {
        printf("\n\t ; # ++++++++++ [ DIV ] ++++++++++++++++++++++++++++++++++++++++++++++++\n");
        printf("\n\t ; #  %s\n", instr->op);
        printf("\n\t ; # temp1: %s :: temp2: %s\n", temp1, temp2);


        printf("\tmovl\t-%s(%%rbp), %%eax\n", temp1);
        printf("\tcltd\n");
        printf("\tidivl\t-%s(%%rbp)\n", temp2);
        if((strcmp(next->op, "storeAI") == 0)){
            printf("\tmovl\t%%eax, -%s(%%rbp)\n", next->arg3);
         }else { 
            printf("\tmovl\t%%eax, %s\n", dest);
         }
        printf("\n\t ; # ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");

    }
}